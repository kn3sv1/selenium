package com.codewithmosh.lambdas;

public interface Printer {
  void print(String message);
}
