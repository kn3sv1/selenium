package com.codewithmosh.streams;

public enum Genre {
  COMEDY,
  ACTION,
  THRILLER
}
