package com.codewithmosh.generics;

public class UserList {
  private User[] items = new User[10];
  private int count;


}
