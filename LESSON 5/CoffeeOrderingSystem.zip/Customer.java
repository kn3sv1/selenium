public class Customer {
    public void order(Coffee coffee) {
        System.out.println("You ordered: " + coffee.getDescription());
        System.out.println("Total cost: $" + coffee.getCost());
    }
}