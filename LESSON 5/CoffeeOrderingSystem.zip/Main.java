public class Main {
    public static void main(String[] args) {
        Coffee baseCoffee = new Latte();
        Coffee withMilk = new Milk(baseCoffee);
        Coffee withMilkAndSugar = new Sugar(withMilk);

        Customer customer = new Customer();
        customer.order(withMilkAndSugar);
    }
}