public class Milk extends CoffeeSupplement {
    public Milk(Coffee coffee) {
        super(coffee);
    }

    public String getDescription() {
        return baseCoffee.getDescription() + ", Milk";
    }

    public double getCost() {
        return baseCoffee.getCost() + 0.5;
    }
}