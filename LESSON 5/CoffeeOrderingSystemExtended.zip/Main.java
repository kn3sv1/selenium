public class Main {
    public static void main(String[] args) {
        Coffee mocha = new Mocha();
        Coffee withCaramel = new Caramel(mocha);
        Coffee fullOrder = new Sugar(new Milk(withCaramel));

        Customer customer = new Customer();
        customer.order(fullOrder);
    }
}