public class Caramel extends CoffeeSupplement {
    public Caramel(Coffee coffee) {
        super(coffee);
    }

    public String getDescription() {
        return baseCoffee.getDescription() + ", Caramel";
    }

    public double getCost() {
        return baseCoffee.getCost() + 0.6;
    }
}