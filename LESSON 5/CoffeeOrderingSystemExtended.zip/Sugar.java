public class Sugar extends CoffeeSupplement {
    public Sugar(Coffee coffee) {
        super(coffee);
    }

    public String getDescription() {
        return baseCoffee.getDescription() + ", Sugar";
    }

    public double getCost() {
        return baseCoffee.getCost() + 0.2;
    }
}