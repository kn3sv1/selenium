public class Espresso implements Coffee {
    public String getDescription() {
        return "Espresso";
    }

    public double getCost() {
        return 2.0;
    }
}