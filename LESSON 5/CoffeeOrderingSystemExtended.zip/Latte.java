public class Latte implements Coffee {
    public String getDescription() {
        return "Latte";
    }

    public double getCost() {
        return 2.5;
    }
}