public class Mocha implements Coffee {
    public String getDescription() {
        return "Mocha";
    }

    public double getCost() {
        return 3.0;
    }
}