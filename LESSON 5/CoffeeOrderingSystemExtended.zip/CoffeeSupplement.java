public abstract class CoffeeSupplement implements Coffee {
    protected Coffee baseCoffee;

    public CoffeeSupplement(Coffee coffee) {
        this.baseCoffee = coffee;
    }
}